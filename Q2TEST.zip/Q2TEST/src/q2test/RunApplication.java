/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package q2test;

/**
 *
 * @author caleb
 */
public class RunApplication {
    public static void main(String[] args) {
        RoadAccidentReport report = new RoadAccidentReport("Car", "New York", 5);
        report.printAccidentReport();
    }
}